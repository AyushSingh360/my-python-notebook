# Basic string syntax examples
s1 = 'single quotes'
s2 = "double quotes"
s3 = """multi-line
string"""
print(s1)
print(s2)
print(s3)
# Concatenation and repetition
print(s1 + " " + s2)
print(s1 * 3)
# f‑string formatting
name = "Bob"
print(f"Hello, {name}!")
