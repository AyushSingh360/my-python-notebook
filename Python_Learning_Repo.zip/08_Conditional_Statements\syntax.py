# Basic conditional syntax examples
x = 10
if x > 5:
    print("Greater")
else:
    print("Not greater")

# if-elif-else chain
score = 85
if score >= 90:
    grade = "A"
elif score >= 80:
    grade = "B"
else:
    grade = "F"
print(grade)
