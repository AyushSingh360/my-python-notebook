# Minimal syntax examples for data types and operators

# Integers and floats
x = 10
y = 3.14
print(x + y)  # 13.14

# Strings
s = "hello"
print(s * 3)  # hellohellohello

# Booleans and logical operators
flag = True
if flag and (x > 5):
    print("Condition met")
else:
    print("Condition not met")
