# Strings

Placeholder content for Strings chapter README.
